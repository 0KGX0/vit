.. vim: set fileencoding=utf-8 :

===========
References
===========

.. [GMV21] *A. George, S. Marcel*, **On the Effectiveness of Vision Transformers for Zero-shot Face Anti-Spoofing**,
            in: International Joint Conference on Biometrics (IJCB 2021), 2021.