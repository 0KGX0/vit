

.. This file contains all links we use for documentation in a centralized place


.. _idiap: http://www.idiap.ch
.. _bob: http://www.idiap.ch/software/bob
.. _buildout: http://www.buildout.org
.. _pypi: http://pypi.python.org
.. _installation: https://www.idiap.ch/software/bob/install
.. _dependencies: https://gitlab.idiap.ch/bob/bob/wikis/Dependencies


