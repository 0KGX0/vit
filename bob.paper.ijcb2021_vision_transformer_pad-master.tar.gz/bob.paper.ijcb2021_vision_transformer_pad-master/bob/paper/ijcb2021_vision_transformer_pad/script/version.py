#!/usr/bin/env python
# vim: set fileencoding=utf-8 :

"""
Print the text
"""

def main():
  """Print the text"""

  print ("Print test text")
  return 0

